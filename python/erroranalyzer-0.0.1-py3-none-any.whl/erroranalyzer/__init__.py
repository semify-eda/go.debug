"""ErrorAnalyzer"""
__author__ = "Klaus Strohmayer"
__copyright__ = "Copyright (c) 2020 by Klaus Strohmayer"
__license__ = "proprietary"
__credits__ = [
    "Leo Moser"
]
__maintainer__ = "Leo Moser"
__email__ = "-"
__version__ = "0.0.1"

from erroranalyzer.erroranalyzer import *
