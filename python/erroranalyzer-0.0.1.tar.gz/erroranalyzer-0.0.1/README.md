# erroranalyzer

This package is a Python wrapper to call the ErrorAnalyzer library.

---

Import the package

> from erroranalyzer import eaAnalyzer, eaAnalyzersFinal

and create your first analyzer

> # Create the first analyzer, 8 Bit, unsigned
> my_analyzer = eaAnalyzer("Analyzer 1", 8, False)

add samples

> my_analyzer.add_sample(data_read=1, data_expected=2, time=1000)

and print the final report

> eaAnalyzersFinal()

# Environment Variables

Set `EA_ROOT` to point to the directory containing the license file. Otherwise the trial version will be used.
Set `EA_CONFIG` to point to the directory containing the config file. Otherwise the standard configuration will be used.
